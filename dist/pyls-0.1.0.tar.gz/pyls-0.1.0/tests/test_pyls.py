import json
import pytest
import subprocess
import os
import sys

# Add parent directory to the python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Sample JSON data for testing
directory_structure = {
    "name": "interpreter",
    "size": 4096,
    "time_modified": 1699957865,
    "permissions": "drwxr-xr-x",
    "contents": [
        {
            "name": ".gitignore",
            "size": 8911,
            "time_modified": 1699941437,
            "permissions": "-rw-r--r--"},
        {
            "name": "LICENSE",
            "size": 1071,
            "time_modified": 1699941437,
            "permissions": "-rw-r--r--"},
        {
            "name": "README.md", "size": 83,
            "time_modified": 1699941437,
            "permissions": "-rw-r--r--"},
        {
            "name": "ast", "size": 4096,
            "time_modified": 1699957739,
            "permissions": "drwxr-xr-x",
            "contents": [
                {
                    "name": "go.mod",
                    "size": 225,
                    "time_modified": 1699957780,
                    "permissions": "-rw-r--r--"
                }
            ]
        },
        {
            "name": "lexer",
            "size": 4096,
            "time_modified": 1699957740,
            "permissions": "drwxr-xr-x"
        },
        {
            "name": "main.go",
            "size": 3456,
            "time_modified": 1699957790,
            "permissions": "-rw-r--r--"
        },
        {
            "name": "parser",
            "size": 4096,
            "time_modified": 1699957740,
            "permissions": "drwxr-xr-x",
            "contents": [
                {
                    "name": "token",
                    "size": 1234,
                    "time_modified": 1699957795,
                    "permissions": "-rw-r--r--"
                }
            ]
        }
    ]
}


# Write the sample JSON data to a file
@pytest.fixture(scope="module", autouse=True)
def setup_directory_json():
    with open('directory_test.json', 'w') as f:
        json.dump(directory_structure, f)
    yield
    os.remove('directory_test.json')


# Helper function to run the pyls script
def run_pyls(args):
    result = subprocess.run(['python3', 'pyls.py'] + args, capture_output=True, text=True)
    print(f"Running pyls with argument: {args}")
    print(f"Output:\n{result.stdout.strip()}")
    print(f"Errors:\n{result.stderr.strip()}")
    return result.stdout.strip(), result.stderr.strip()


def test_ls_default():
    # expected_output = "LICENSE\nREADME.md\nast\nlexer\nmain.go\nparser"
    expected_output = ('LICENSE\nREADME.md\nast\nlexer\nmain.go\nparser', '')
    assert run_pyls([]) == expected_output


def test_ls_all():
    expected_output = ('.gitignore\nLICENSE\nREADME.md\nast\nlexer\nmain.go\nparser', '')
    assert run_pyls(['-a']) == expected_output


def test_ls_recursive():
    expected_output = ('LICENSE\nREADME.md\nast\n    go.mod\nlexer\nmain.go\nparser\n    token', '')
    assert run_pyls(['-R']) == expected_output


def test_ls_descriptive_format():
    result = run_pyls(['-l']) # Check for expected parts in the output (permissions, sizes, times, names)
    assert "drwxr-xr-x" in result
    assert "1.04 KB" in result
    assert "README.md" in result


def test_ls_reverse():
    expected_output = ('parser\nmain.go\nlexer\nast\nREADME.md\nLICENSE', '')
    assert run_pyls(['-r']) == expected_output


def test_ls_sort_time():
    expected_output = ('LICENSE\nREADME.md\nast\nlexer\nparser\nmain.go', '')
    assert run_pyls(['-t']) == expected_output


def test_ls_filter_file():
    expected_output = ('LICENSE\nREADME.md\nlexer\nmain.go', '')
    assert run_pyls(['--filter=file']) == expected_output


def test_ls_filter_dir():
    expected_output = ('ast\nparser', '')
    assert run_pyls(['--filter=dir']) == expected_output


def test_ls_subdirectory():
    expected_output = ('token', '')
    assert run_pyls(['parser']) == expected_output


"""def test_ls_subdirectory_long_format():
    result = run_pyls(['-l', 'parser'])
    assert "token" in result
    assert "1.21 KB" in result
    assert "-rw-r--r--" in result"""


def test_ls_human_readable_size():
    expected_output = ('sourav')
    assert run_pyls(['-h']) == expected_output
